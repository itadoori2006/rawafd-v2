RawaFD static asset recovery bundle. CSS assets restored for the prebuilt OpenNext worker.
